SNOW RIDER 3D - CUSTOM APP ICON UPDATE

This is the original Snow Rider Android project with a custom launcher icon added.
The game files and gameplay code have not been changed.

To make a new APK:
1. Upload this ZIP to the same GitHub repository used for the original Snow Rider APK.
2. Replace the old project ZIP in the repository, or upload this ZIP alongside it.
3. If your existing workflow automatically picks the first ZIP, remove the old ZIP first so it selects this updated ZIP.
4. Run the existing Build Snow Rider APK workflow in the Actions tab.
5. Download the APK artifact when the workflow succeeds.
